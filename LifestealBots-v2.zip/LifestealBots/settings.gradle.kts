rootProject.name = "LifestealBots"
