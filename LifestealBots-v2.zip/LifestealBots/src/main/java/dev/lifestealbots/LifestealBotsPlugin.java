package dev.lifestealbots;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class LifestealBotsPlugin extends JavaPlugin implements Listener {
    private PacketBotManager botManager;
    private ChatBrain chatBrain;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.botManager = new PacketBotManager(this);
        this.chatBrain = new ChatBrain(this);
        botManager.loadProfiles();

        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("lsbot");
        if (cmd != null) cmd.setExecutor(new BotCommand(this));

        Bukkit.getScheduler().runTaskTimer(this, () -> botManager.balanceOnlinePopulation(), 40L, 100L);
        Bukkit.getScheduler().runTaskTimer(this, () -> botManager.tickPhysicalMovement(), 20L, 1L);

        long intervalTicks = getConfig().getLong("bots.activity-interval-seconds", 55L) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> chatBrain.triggerSimulatedServerEvent(botManager.getOnlineBots()), intervalTicks, intervalTicks);

        getLogger().info("LifestealBots enabled (RAM-only zero-footprint mode).");
    }

    @Override
    public void onDisable() {
        Bukkit.getScheduler().cancelTasks(this);
        if (botManager != null) {
            botManager.despawnAll();
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> botManager.sendAllToViewer(event.getPlayer()), 20L);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerChat(AsyncChatEvent event) {
        String plain = PlainTextComponentSerializer.plainText().serialize(event.message());
        chatBrain.handlePlayerMessage(event.getPlayer().getName(), plain, botManager.getOnlineBots());
    }

    public PacketBotManager getBotManager() { return botManager; }
    public ChatBrain getChatBrain() { return chatBrain; }
}
