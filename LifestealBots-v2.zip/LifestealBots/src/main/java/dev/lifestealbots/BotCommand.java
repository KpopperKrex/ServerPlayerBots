package dev.lifestealbots;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class BotCommand implements CommandExecutor {
    private final LifestealBotsPlugin plugin;

    public BotCommand(LifestealBotsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("lifestealbots.admin")) {
            sender.sendMessage(color("&cNo permission."));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(color("&6&lLifestealBots &7Commands:"));
            sender.sendMessage(color("&e/lsbot list &7- Show online bots"));
            sender.sendMessage(color("&e/lsbot spawn <name> &7- Connect a bot"));
            sender.sendMessage(color("&e/lsbot remove <name> &7- Disconnect a bot"));
            sender.sendMessage(color("&e/lsbot count <number> &7- Set target online count"));
            sender.sendMessage(color("&e/lsbot chat <bot> <msg> &7- Force a bot to chat"));
            sender.sendMessage(color("&e/lsbot reload &7- Reload config.yml"));
            sender.sendMessage(color("&c/lsbot panic &7- Emergency wipe & disable plugin"));
            return true;
        }

        var manager = plugin.getBotManager();
        switch (args[0].toLowerCase()) {
            case "list" -> {
                sender.sendMessage(color("&aOnline Bots (" + manager.getOnlineBots().size() + "):"));
                for (BotProfile b : manager.getOnlineBots()) {
                    sender.sendMessage(color(" &7- &f" + b.getName() + " &8(&c" + b.getHearts() + "❤&8, " + b.getState() + ")"));
                }
            }
            case "spawn" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&cUsage: /lsbot spawn <name>"));
                    return true;
                }
                BotProfile found = manager.getAllProfiles().stream()
                        .filter(b -> b.getName().equalsIgnoreCase(args[1]))
                        .findFirst()
                        .orElse(new BotProfile(args[1], "&8[&7Member&8] ", 10, "DIAMOND", "friendly Indian SMP player"));
                manager.connectBot(found, true);
                sender.sendMessage(color("&aSpawned bot &f" + found.getName()));
            }
            case "remove" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&cUsage: /lsbot remove <name>"));
                    return true;
                }
                BotProfile bot = manager.getBot(args[1]);
                if (bot == null) {
                    sender.sendMessage(color("&cBot not online."));
                    return true;
                }
                manager.disconnectBot(bot, true);
                sender.sendMessage(color("&eDisconnected &f" + bot.getName()));
            }
            case "count" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&cUsage: /lsbot count <number>"));
                    return true;
                }
                int count = Integer.parseInt(args[1]);
                plugin.getConfig().set("bots.target-online", count);
                plugin.saveConfig();
                for (int i = 0; i < 12; i++) manager.balanceOnlinePopulation();
                sender.sendMessage(color("&aTarget bot count set to &f" + count));
            }
            case "chat" -> {
                if (args.length < 3) {
                    sender.sendMessage(color("&cUsage: /lsbot chat <bot> <message>"));
                    return true;
                }
                BotProfile bot = manager.getBot(args[1]);
                if (bot == null) {
                    sender.sendMessage(color("&cBot not online."));
                    return true;
                }
                String msg = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                plugin.getChatBrain().sendBotChat(bot, msg);
            }
            case "reload" -> {
                plugin.reloadConfig();
                manager.loadProfiles();
                sender.sendMessage(color("&aLifestealBots config reloaded."));
            }
            case "panic" -> {
                manager.despawnAll();
                Bukkit.getScheduler().cancelTasks(plugin);
                sender.sendMessage(color("&c[LifestealBots] Emergency wipe complete. Disabling plugin now..."));
                Bukkit.getPluginManager().disablePlugin(plugin);
            }
            default -> sender.sendMessage(color("&cUnknown subcommand. Use /lsbot"));
        }
        return true;
    }

    private net.kyori.adventure.text.Component color(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }
}
